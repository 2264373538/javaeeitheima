package com.itheima;
public class Bean2 {
    public Bean2(){
        System.out.println("这是Bean2");
    }
}