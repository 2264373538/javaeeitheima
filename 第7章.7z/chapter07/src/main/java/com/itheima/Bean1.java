package com.itheima;
public class Bean1 {
    public Bean1(){
        System.out.println("这是Bean1");
    }
}