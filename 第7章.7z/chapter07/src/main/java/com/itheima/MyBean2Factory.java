package com.itheima;
public class MyBean2Factory {
    //使用MyBean2Factory类的工厂创建Bean2实例
    public static Bean2 createBean(){
        return new Bean2();
    }
}