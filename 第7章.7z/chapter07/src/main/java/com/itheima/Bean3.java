package com.itheima;
public class Bean3 {
    public Bean3(){
        System.out.println("这是Bean3");
    }
}