package com.itheima.demo03;
public interface UserDao {
    public void insert();
    public void delete();
    public void update();
    public void select();
}