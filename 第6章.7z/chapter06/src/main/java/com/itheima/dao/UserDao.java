package com.itheima.dao;
public interface UserDao {
    public boolean login(String name,String password);
}