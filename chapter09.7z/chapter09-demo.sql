use spring;
create table student(
    id int(11) primary key auto_increment,
    username varchar(255),
    password varchar(255),
		course varchar(255)
);
