package com.itheima.service;

import com.itheima.domain.Book;

public interface BookService {
    public Book findBookById(Integer id);
}

