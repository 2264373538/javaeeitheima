package com.itheima.dao;

import com.itheima.domain.Book;

public interface BookMapper {
    public Book findBookById(Integer id);
}

