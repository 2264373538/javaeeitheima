package com.itheima.mapper;

import com.itheima.pojo.Users;

public interface UsersMapper {

    public Users findUserWithOrders(Integer id);
}