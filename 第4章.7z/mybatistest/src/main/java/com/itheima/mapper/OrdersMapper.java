package com.itheima.mapper;

import com.itheima.pojo.Orders;

public interface OrdersMapper {
    public Orders findOrdersWithPorduct(Integer id);
}