package com.itheima.mapper;

import com.itheima.pojo.IdCard;

/**
 * @author wyn
 * @create 2022-03-14 1:48
 **/
public interface IdCardMapper {
    public IdCard findCodeById(Integer id);
}
