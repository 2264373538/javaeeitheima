package com.itheima.mapper;

import com.itheima.pojo.Orders;
import com.itheima.pojo.Product;

public interface ProductMapper {
    public Product findProductById(Integer id);
}