package com.itheima.mapper;

import com.itheima.pojo.Book;

import java.util.List;

/**
 * @author wyn
 * @create 2022-03-14 1:18
 **/
public interface BookMapper {
    public Book findBookById(Integer id);
    public int updateBook(Book book);

}
