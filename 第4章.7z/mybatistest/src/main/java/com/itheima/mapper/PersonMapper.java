package com.itheima.mapper;

import com.itheima.pojo.Person;

/**
 * @author wyn
 * @create 2022-03-14 2:07
 **/
public interface PersonMapper {
    //嵌套查询：通过执行另外一条SQL映射语句来返回预期的特殊类型
    public Person findPersonById(Integer id);
}
